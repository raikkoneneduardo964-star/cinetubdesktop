package database;

public class BancoDeDados {package com.example.cinetubdesktop.database;

import com.example.cinetubdesktop.model.Funcionario;
import com.example.cinetubdesktop.model.Filme;
import com.example.cinetubdesktop.model.Sala;

import java.util.ArrayList;

    public class BancoDeDados {
        public static ArrayList<Livro> livros=new ArrayList<>();

        public static ArrayList<Aluno> alunos=new ArrayList<>();


    }
}
