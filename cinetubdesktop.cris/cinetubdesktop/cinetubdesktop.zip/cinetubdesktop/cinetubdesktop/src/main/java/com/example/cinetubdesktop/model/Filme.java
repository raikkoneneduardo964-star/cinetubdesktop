package com.example.trabalho.model;

public class Filme {

    private Long id;
    private String titulo;
    private String genero;
    private int anoLancamento;
    private double avaliacao;

    // Construtor vazio (necessário para frameworks e instanciações simples)
    public Filme() {
    }

    // Construtor completo
    public Filme(Long id, String titulo, String genero, int anoLancamento, double avaliacao) {
        this.id = id;
        this.titulo = titulo;
        this.genero = genero;
        this.anoLancamento = anoLancamento;
        this.avaliacao = avaliacao;
    }

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getAnoLancamento() {
        return anoLancamento;
    }

    public void setAnoLancamento(int anoLancamento) {
        this.anoLancamento = anoLancamento;
    }

    public double getAvaliacao() {
        return avaliacao;
    }

    public void setAvaliacao(double avaliacao) {
        this.avaliacao = avaliacao;
    }

    @Override
    public String toString() {
        return titulo; // Facilita a exibição em componentes visuais como ListView/ComboBox
    }
}